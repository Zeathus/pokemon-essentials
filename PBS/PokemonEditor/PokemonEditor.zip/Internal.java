interface Internal {

    public int getID();
    public String getInternalName();

    public void setInternalName(String value);

}